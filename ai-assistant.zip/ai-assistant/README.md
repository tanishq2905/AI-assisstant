# AI Assistant

A personal AI assistant powered by Claude (Anthropic), built with Node.js and Express.

## Features
- Real-time streaming responses
- Conversation memory within a session
- Clean, dark-mode chat UI
- RESTful API backend

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Add your API key
```bash
cp .env.example .env
```
Then open `.env` and replace `your_api_key_here` with your Anthropic API key.
Get one at: https://console.anthropic.com

### 3. Run the app
```bash
# Production
npm start

# Development (auto-restarts on changes)
npm run dev
```

### 4. Open in browser
Visit: http://localhost:3000

## Project Structure
```
ai-assistant/
├── public/
│   └── index.html      # Frontend chat UI
├── src/
│   └── server.js       # Express server + Claude API
├── .env.example        # Environment variables template
├── .env                # Your actual API key (git-ignored)
└── package.json
```

## Tech Stack
- **Backend**: Node.js, Express
- **AI**: Anthropic Claude API (claude-sonnet-4)
- **Streaming**: Server-Sent Events (SSE)
- **Frontend**: Vanilla HTML/CSS/JS
